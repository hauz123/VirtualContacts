#import "VirtualContactsPreferencesController.h"
#import "VirtualContactsManager.h"

@interface VirtualContactsPreferencesController ()

@property (nonatomic, strong) UIView *headerContainerView;
@property (nonatomic, strong) UILabel *statusBadgeLabel;
@property (nonatomic, strong) UILabel *countValueLabel;
@property (nonatomic, strong) UILabel *storageSourceLabel;
@property (nonatomic, strong) UILabel *progressStatusLabel;
@property (nonatomic, strong) UIProgressView *progressBar;

@property (nonatomic, strong) PSSpecifier *generateButtonSpecifier;
@property (nonatomic, strong) PSSpecifier *deleteButtonSpecifier;
@property (nonatomic, strong) PSSpecifier *refreshButtonSpecifier;

@property (nonatomic, assign) NSUInteger currentVirtualCount;

@end

@implementation VirtualContactsPreferencesController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Virtual Contacts";
    [self setupModernHeaderCard];
    [self refreshStateSilently];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self refreshStateSilently];
}

#pragma mark - Modern iOS Header Dashboard

- (void)setupModernHeaderCard {
    CGFloat width = self.view.bounds.size.width > 0 ? self.view.bounds.size.width : 375.0;
    UIView *wrapper = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, 215.0)];
    wrapper.backgroundColor = [UIColor clearColor];

    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    card.layer.cornerRadius = 16.0;
    card.layer.masksToBounds = YES;
    [wrapper addSubview:card];

    [NSLayoutConstraint activateConstraints:@[
        [card.topAnchor constraintEqualToAnchor:wrapper.topAnchor constant:12.0],
        [card.leadingAnchor constraintEqualToAnchor:wrapper.leadingAnchor constant:16.0],
        [card.trailingAnchor constraintEqualToAnchor:wrapper.trailingAnchor constant:-16.0],
        [card.bottomAnchor constraintEqualToAnchor:wrapper.bottomAnchor constant:-8.0]
    ]];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = @"Virtual Contacts";
    titleLabel.font = [UIFont systemFontOfSize:22.0 weight:UIFontWeightBold];
    titleLabel.textColor = [UIColor labelColor];
    [card addSubview:titleLabel];

    UILabel *subtitleLabel = [[UILabel alloc] init];
    subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    subtitleLabel.text = @"Fake Contact Generator (VN Edition)";
    subtitleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightMedium];
    subtitleLabel.textColor = [UIColor secondaryLabelColor];
    [card addSubview:subtitleLabel];

    self.statusBadgeLabel = [[UILabel alloc] init];
    self.statusBadgeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.statusBadgeLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    self.statusBadgeLabel.textAlignment = NSTextAlignmentCenter;
    self.statusBadgeLabel.layer.cornerRadius = 10.0;
    self.statusBadgeLabel.layer.masksToBounds = YES;
    self.statusBadgeLabel.text = @"  Đang kiểm tra...  ";
    [card addSubview:self.statusBadgeLabel];

    self.countValueLabel = [[UILabel alloc] init];
    self.countValueLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.countValueLabel.font = [UIFont monospacedDigitSystemFontOfSize:34.0 weight:UIFontWeightHeavy];
    self.countValueLabel.textColor = [UIColor systemBlueColor];
    self.countValueLabel.text = @"0 / 100";
    [card addSubview:self.countValueLabel];

    UILabel *countCaptionLabel = [[UILabel alloc] init];
    countCaptionLabel.translatesAutoresizingMaskIntoConstraints = NO;
    countCaptionLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightRegular];
    countCaptionLabel.textColor = [UIColor secondaryLabelColor];
    countCaptionLabel.text = @"Danh bạ ảo hiện có trong ứng dụng Danh bạ";
    [card addSubview:countCaptionLabel];

    self.storageSourceLabel = [[UILabel alloc] init];
    self.storageSourceLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.storageSourceLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightMedium];
    self.storageSourceLabel.textColor = [UIColor tertiaryLabelColor];
    self.storageSourceLabel.text = @"Bộ nhớ: Đang kiểm tra nguồn lưu trữ...";
    [card addSubview:self.storageSourceLabel];

    self.progressBar = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
    self.progressBar.translatesAutoresizingMaskIntoConstraints = NO;
    self.progressBar.progress = 0.0;
    self.progressBar.hidden = YES;
    [card addSubview:self.progressBar];

    self.progressStatusLabel = [[UILabel alloc] init];
    self.progressStatusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.progressStatusLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightMedium];
    self.progressStatusLabel.textColor = [UIColor systemBlueColor];
    self.progressStatusLabel.text = @"";
    self.progressStatusLabel.hidden = YES;
    [card addSubview:self.progressStatusLabel];

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.topAnchor constraintEqualToAnchor:card.topAnchor constant:16.0],
        [titleLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16.0],

        [self.statusBadgeLabel.centerYAnchor constraintEqualToAnchor:titleLabel.centerYAnchor],
        [self.statusBadgeLabel.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-16.0],
        [self.statusBadgeLabel.heightAnchor constraintEqualToConstant:24.0],

        [subtitleLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:2.0],
        [subtitleLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16.0],

        [self.countValueLabel.topAnchor constraintEqualToAnchor:subtitleLabel.bottomAnchor constant:12.0],
        [self.countValueLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16.0],

        [countCaptionLabel.topAnchor constraintEqualToAnchor:self.countValueLabel.bottomAnchor constant:2.0],
        [countCaptionLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16.0],

        [self.storageSourceLabel.topAnchor constraintEqualToAnchor:countCaptionLabel.bottomAnchor constant:6.0],
        [self.storageSourceLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16.0],
        [self.storageSourceLabel.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-16.0],

        [self.progressBar.topAnchor constraintEqualToAnchor:self.storageSourceLabel.bottomAnchor constant:10.0],
        [self.progressBar.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16.0],
        [self.progressBar.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-16.0],

        [self.progressStatusLabel.topAnchor constraintEqualToAnchor:self.progressBar.bottomAnchor constant:4.0],
        [self.progressStatusLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16.0]
    ]];

    self.headerContainerView = wrapper;
    self.table.tableHeaderView = wrapper;
}

#pragma mark - Specifiers Setup

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *specs = [NSMutableArray array];

        PSSpecifier *actionGroup = [PSSpecifier groupSpecifierWithName:@"Điều khiển Danh bạ Ảo"];
        [actionGroup setProperty:@"Tạo 100 danh bạ ảo tiếng Việt hiển thị trực tiếp trong ứng dụng Danh bạ. Danh bạ thật của bạn hoàn toàn được bảo vệ."
                          forKey:@"footerText"];
        [specs addObject:actionGroup];

        self.generateButtonSpecifier = [PSSpecifier preferenceSpecifierNamed:@"Generate 100 Contacts"
                                                                      target:self
                                                                         set:NULL
                                                                         get:NULL
                                                                      detail:Nil
                                                                        cell:PSButtonCell
                                                                        edit:Nil];
        [self.generateButtonSpecifier setButtonAction:@selector(didTapGenerateContacts:)];
        [self.generateButtonSpecifier setProperty:@YES forKey:@"enabled"];
        [specs addObject:self.generateButtonSpecifier];

        self.deleteButtonSpecifier = [PSSpecifier preferenceSpecifierNamed:@"Delete Virtual Contacts"
                                                                    target:self
                                                                       set:NULL
                                                                       get:NULL
                                                                    detail:Nil
                                                                      cell:PSButtonCell
                                                                      edit:Nil];
        [self.deleteButtonSpecifier setButtonAction:@selector(didTapDeleteContacts:)];
        [self.deleteButtonSpecifier setProperty:@YES forKey:@"enabled"];
        [specs addObject:self.deleteButtonSpecifier];

        self.refreshButtonSpecifier = [PSSpecifier preferenceSpecifierNamed:@"Refresh"
                                                                     target:self
                                                                        set:NULL
                                                                        get:NULL
                                                                     detail:Nil
                                                                       cell:PSButtonCell
                                                                       edit:Nil];
        [self.refreshButtonSpecifier setButtonAction:@selector(didTapRefresh:)];
        [self.refreshButtonSpecifier setProperty:@YES forKey:@"enabled"];
        [specs addObject:self.refreshButtonSpecifier];

        PSSpecifier *configGroup = [PSSpecifier groupSpecifierWithName:@"Cấu hình dữ liệu giả lập"];
        [configGroup setProperty:@"Số điện thoại sử dụng dải thử nghiệm +84 24 0000 xxxx và email @example.com để tránh trùng với người thật."
                          forKey:@"footerText"];
        [specs addObject:configGroup];

        PSSpecifier *accentSwitch = [PSSpecifier preferenceSpecifierNamed:@"Tên tiếng Việt có dấu"
                                                                  target:self
                                                                     set:@selector(setPreferenceValue:specifier:)
                                                                     get:@selector(readPreferenceValue:)
                                                                  detail:Nil
                                                                    cell:PSSwitchCell
                                                                    edit:Nil];
        [accentSwitch setProperty:@"accented" forKey:@"key"];
        [accentSwitch setProperty:@YES forKey:@"default"];
        [specs addObject:accentSwitch];

        PSSpecifier *avatarSwitch = [PSSpecifier preferenceSpecifierNamed:@"Tạo ảnh đại diện (Avatar chữ cái)"
                                                                  target:self
                                                                     set:@selector(setPreferenceValue:specifier:)
                                                                     get:@selector(readPreferenceValue:)
                                                                  detail:Nil
                                                                    cell:PSSwitchCell
                                                                    edit:Nil];
        [avatarSwitch setProperty:@"avatar" forKey:@"key"];
        [avatarSwitch setProperty:@YES forKey:@"default"];
        [specs addObject:avatarSwitch];

        PSSpecifier *companySwitch = [PSSpecifier preferenceSpecifierNamed:@"Thêm thông tin công ty & chức vụ"
                                                                   target:self
                                                                      set:@selector(setPreferenceValue:specifier:)
                                                                      get:@selector(readPreferenceValue:)
                                                                   detail:Nil
                                                                     cell:PSSwitchCell
                                                                     edit:Nil];
        [companySwitch setProperty:@"company" forKey:@"key"];
        [companySwitch setProperty:@YES forKey:@"default"];
        [specs addObject:companySwitch];

        _specifiers = [specs copy];
    }
    return _specifiers;
}

#pragma mark - Switch Read / Write

- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];
    if ([key isEqualToString:@"accented"]) {
        return @(mgr.useAccentedVietnamese);
    } else if ([key isEqualToString:@"avatar"]) {
        return @(mgr.includeAvatarImages);
    } else if ([key isEqualToString:@"company"]) {
        return @(mgr.includeCompanyInfo);
    }
    return [specifier propertyForKey:@"default"];
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    BOOL boolVal = [value boolValue];
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];
    if ([key isEqualToString:@"accented"]) {
        mgr.useAccentedVietnamese = boolVal;
    } else if ([key isEqualToString:@"avatar"]) {
        mgr.includeAvatarImages = boolVal;
    } else if ([key isEqualToString:@"company"]) {
        mgr.includeCompanyInfo = boolVal;
    }
}

#pragma mark - State & UI Synchronization

- (void)refreshStateSilently {
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];
    [mgr requestContactsAccessWithCompletion:^(BOOL granted, NSError * _Nullable error) {
        if (!granted) {
            self.currentVirtualCount = 0;
            [self updateDashboardUIWithAuthorized:NO busy:NO];
            return;
        }
        NSUInteger count = [mgr syncAndCountExistingVirtualContacts];
        self.currentVirtualCount = count;
        [self updateDashboardUIWithAuthorized:YES busy:mgr.isBusy];
    }];
}

- (void)updateDashboardUIWithAuthorized:(BOOL)authorized busy:(BOOL)busy {
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];
    NSUInteger target = mgr.targetContactCount;

    self.countValueLabel.text = [NSString stringWithFormat:@"%lu / %lu", (unsigned long)self.currentVirtualCount, (unsigned long)target];

    if (!authorized) {
        self.statusBadgeLabel.text = @"  Chưa cấp quyền  ";
        self.statusBadgeLabel.textColor = [UIColor systemOrangeColor];
        self.statusBadgeLabel.backgroundColor = [[UIColor systemOrangeColor] colorWithAlphaComponent:0.15];
        self.storageSourceLabel.text = @"Vui lòng cấp quyền truy cập Danh bạ để sử dụng.";
    } else if (busy) {
        self.statusBadgeLabel.text = @"  Đang xử lý...  ";
        self.statusBadgeLabel.textColor = [UIColor systemBlueColor];
        self.statusBadgeLabel.backgroundColor = [[UIColor systemBlueColor] colorWithAlphaComponent:0.15];
    } else {
        self.statusBadgeLabel.text = @"  Sẵn sàng hoạt động  ";
        self.statusBadgeLabel.textColor = [UIColor systemGreenColor];
        self.statusBadgeLabel.backgroundColor = [[UIColor systemGreenColor] colorWithAlphaComponent:0.15];

        if ([mgr hasLocalContainerAvailable]) {
            self.storageSourceLabel.text = @"Nguồn lưu: Bộ nhớ cục bộ iPhone (Không đồng bộ iCloud)";
        } else {
            self.storageSourceLabel.text = @"Nguồn lưu: Tài khoản mặc định (Đang bật iCloud Contacts)";
        }
    }

    BOOL canGenerate = (!busy && self.currentVirtualCount < target);
    BOOL canDelete = (!busy && self.currentVirtualCount > 0);
    BOOL canRefresh = (!busy);

    [self.generateButtonSpecifier setProperty:@(canGenerate) forKey:@"enabled"];
    [self.deleteButtonSpecifier setProperty:@(canDelete) forKey:@"enabled"];
    [self.refreshButtonSpecifier setProperty:@(canRefresh) forKey:@"enabled"];
    [self reloadSpecifiers];
}

#pragma mark - Button Actions

- (void)didTapGenerateContacts:(PSSpecifier *)specifier {
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];
    if (mgr.isBusy) {
        return;
    }

    if (self.currentVirtualCount >= mgr.targetContactCount) {
        [self showAlertWithTitle:@"Đã đủ 100 danh bạ ảo"
                         message:@"Hệ thống đã có sẵn 100 danh bạ ảo. Vui lòng nhấn 'Delete Virtual Contacts' trước khi tạo bộ danh bạ mới."];
        return;
    }

    [self startGenerationWithCloudFallback:NO];
}

- (void)startGenerationWithCloudFallback:(BOOL)allowCloudFallback {
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];
    NSUInteger target = mgr.targetContactCount;

    self.progressBar.hidden = NO;
    self.progressBar.progress = 0.0;
    self.progressStatusLabel.hidden = NO;
    self.progressStatusLabel.text = @"Đang khởi tạo danh bạ ảo...";
    [self updateDashboardUIWithAuthorized:YES busy:YES];

    [mgr generateVirtualContactsWithCount:target
                       allowCloudFallback:allowCloudFallback
                                 progress:^(NSUInteger current, NSUInteger total) {
        float ratio = total > 0 ? (float)current / (float)total : 0.0f;
        [self.progressBar setProgress:ratio animated:YES];
        self.progressStatusLabel.text = [NSString stringWithFormat:@"Đang tạo: %lu / %lu liên hệ...", (unsigned long)current, (unsigned long)total];
    } completion:^(NSUInteger createdCount, BOOL usedLocalContainer, NSError * _Nullable error) {
        self.progressBar.hidden = YES;
        self.progressStatusLabel.hidden = YES;

        if (error && error.code == VCErrorCodeNoLocalContainer) {
            [self refreshStateSilently];
            [self promptCloudFallbackConfirmation];
            return;
        }

        [self refreshStateSilently];

        if (error) {
            NSString *msg = [NSString stringWithFormat:@"Đã tạo được %lu liên hệ trước khi gặp lỗi:\n%@",
                             (unsigned long)createdCount, error.localizedDescription];
            [self showAlertWithTitle:@"Quá trình tạo bị gián đoạn" message:msg];
        } else {
            NSString *locationInfo = usedLocalContainer
                ? @"Danh bạ được lưu cục bộ trên iPhone (không đẩy lên iCloud)."
                : @"Danh bạ được lưu vào nhóm riêng 'Virtual Contacts'.";
            NSString *msg = [NSString stringWithFormat:@"Đã tạo thành công %lu danh bạ ảo tiếng Việt!\n\n%@\n\nBạn có thể mở ứng dụng Danh bạ mặc định để kiểm tra ngay.",
                             (unsigned long)createdCount, locationInfo];
            [self showAlertWithTitle:@"Tạo danh bạ thành công" message:msg];
        }
    }];
}

- (void)promptCloudFallbackConfirmation {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Phát hiện đang bật iCloud Contacts"
                                                                   message:@"Khi bật iCloud Contacts, iOS ẩn bộ nhớ danh bạ cục bộ nên các liên hệ mới sẽ nằm trong tài khoản mặc định (nhóm 'Virtual Contacts').\n\nBạn muốn tiếp tục tạo hay hủy để tắt tạm iCloud Contacts trước?"
                                                            preferredStyle:UIAlertControllerStyleAlert];

    [alert addAction:[UIAlertAction actionWithTitle:@"Hủy (Khuyên dùng)" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Tiếp tục tạo" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self startGenerationWithCloudFallback:YES];
    }]];

    [self presentViewController:alert animated:YES completion:nil];
}

- (void)didTapDeleteContacts:(PSSpecifier *)specifier {
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];
    if (mgr.isBusy || self.currentVirtualCount == 0) {
        return;
    }

    NSString *confirmMsg = [NSString stringWithFormat:@"Bạn có chắc chắn muốn xóa toàn bộ %lu danh bạ ảo do tweak tạo không?\n\nHệ thống chỉ xóa các liên hệ có định danh của Virtual Contacts. Danh bạ thật của bạn hoàn toàn không bị ảnh hưởng.",
                            (unsigned long)self.currentVirtualCount];

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Xác nhận xóa danh bạ ảo"
                                                                   message:confirmMsg
                                                            preferredStyle:UIAlertControllerStyleAlert];

    [alert addAction:[UIAlertAction actionWithTitle:@"Hủy" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Xóa danh bạ ảo" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [self performDeletion];
    }]];

    [self presentViewController:alert animated:YES completion:nil];
}

- (void)performDeletion {
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];

    self.progressBar.hidden = NO;
    self.progressBar.progress = 0.0;
    self.progressStatusLabel.hidden = NO;
    self.progressStatusLabel.text = @"Đang xóa danh bạ ảo...";
    [self updateDashboardUIWithAuthorized:YES busy:YES];

    [mgr deleteAllVirtualContactsWithProgress:^(NSUInteger current, NSUInteger total) {
        float ratio = total > 0 ? (float)current / (float)total : 0.0f;
        [self.progressBar setProgress:ratio animated:YES];
        self.progressStatusLabel.text = [NSString stringWithFormat:@"Đang xóa: %lu / %lu liên hệ...", (unsigned long)current, (unsigned long)total];
    } completion:^(NSUInteger deletedCount, NSError * _Nullable error) {
        self.progressBar.hidden = YES;
        self.progressStatusLabel.hidden = YES;
        [self refreshStateSilently];

        if (error) {
            NSString *msg = [NSString stringWithFormat:@"Đã xóa %lu liên hệ nhưng gặp lỗi:\n%@",
                             (unsigned long)deletedCount, error.localizedDescription];
            [self showAlertWithTitle:@"Lỗi khi xóa danh bạ" message:msg];
        } else {
            NSString *msg = [NSString stringWithFormat:@"Đã xóa sạch %lu danh bạ ảo.\nDanh bạ thật của bạn vẫn nguyên vẹn.",
                             (unsigned long)deletedCount];
            [self showAlertWithTitle:@"Xóa hoàn tất" message:msg];
        }
    }];
}

- (void)didTapRefresh:(PSSpecifier *)specifier {
    VirtualContactsManager *mgr = [VirtualContactsManager sharedManager];
    [mgr requestContactsAccessWithCompletion:^(BOOL granted, NSError * _Nullable error) {
        if (!granted) {
            self.currentVirtualCount = 0;
            [self updateDashboardUIWithAuthorized:NO busy:NO];
            [self showAlertWithTitle:@"Thiếu quyền truy cập"
                             message:error.localizedDescription ?: @"Không có quyền truy cập Danh bạ."];
            return;
        }
        NSUInteger count = [mgr syncAndCountExistingVirtualContacts];
        self.currentVirtualCount = count;
        [self updateDashboardUIWithAuthorized:YES busy:NO];

        NSString *msg = [NSString stringWithFormat:@"Đã đồng bộ trạng thái với ứng dụng Danh bạ.\nHiện có %lu danh bạ ảo đang hoạt động.",
                         (unsigned long)count];
        [self showAlertWithTitle:@"Đã làm mới dữ liệu" message:msg];
    }];
}

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
