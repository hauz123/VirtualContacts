# Virtual Contacts – Fake Contact Generator

## Cách 1: Build tự động trên GitHub Actions (Không cần Mac/Linux)
1. Giải nén file ZIP này và đẩy toàn bộ nội dung lên một repository GitHub (Public hoặc Private đều được).
2. Mở tab **Actions** trên GitHub -> chọn **Build VirtualContacts DEB** -> bấm **Run workflow**.
3. Sau khoảng 1 phút, tải xuống artifact `com.virtualcontacts.generator-rootless-deb` (bên trong chứa sẵn file `com.virtualcontacts.generator_1.0.0_iphoneos-arm64.deb`) và mở bằng Sileo trên iPhone.

## Cách 2: Build trực tiếp bằng Theos (macOS / Linux / iPhone có cài Theos)
```bash
chmod +x build.sh
./build.sh
```
File `.deb` sẽ được xuất ra tại `packages/com.virtualcontacts.generator_1.0.0_iphoneos-arm64.deb`.
