#import "VirtualContactsManager.h"

#if __has_include(<rootless.h>)
#import <rootless.h>
#else
#define ROOT_PATH_NS(path) ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"] ? [@"/var/jb" stringByAppendingString:(path)] : (path))
#endif

NSString * const VCErrorDomain = @"com.virtualcontacts.generator.error";

static NSString * const kVCSuiteName = @"com.virtualcontacts.generator";
static NSString * const kVCIdentifiersKey = @"VC_SavedContactIdentifiers";
static NSString * const kVCGroupIdentifierKey = @"VC_SavedGroupIdentifier";
static NSString * const kVCAccentedKey = @"VC_UseAccentedVietnamese";
static NSString * const kVCCompanyKey = @"VC_IncludeCompanyInfo";
static NSString * const kVCAvatarKey = @"VC_IncludeAvatarImages";
static NSString * const kVCGroupName = @"Virtual Contacts";
static NSString * const kVCTestEmailDomain = @"example.com";

@interface VirtualContactsManager ()
@property (nonatomic, strong) CNContactStore *contactStore;
@property (nonatomic, strong) dispatch_queue_t workerQueue;
@property (nonatomic, strong) NSUserDefaults *defaults;
@property (nonatomic, assign, readwrite) BOOL isBusy;
@end

@implementation VirtualContactsManager

+ (instancetype)sharedManager {
    static VirtualContactsManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _contactStore = [[CNContactStore alloc] init];
        _workerQueue = dispatch_queue_create("com.virtualcontacts.generator.worker", DISPATCH_QUEUE_SERIAL);
        _defaults = [[NSUserDefaults alloc] initWithSuiteName:kVCSuiteName];
        _targetContactCount = 100;

        [_defaults registerDefaults:@{
            kVCAccentedKey: @YES,
            kVCCompanyKey: @YES,
            kVCAvatarKey: @YES
        }];
    }
    return self;
}

#pragma mark - Settings Properties

- (BOOL)useAccentedVietnamese {
    return [self.defaults boolForKey:kVCAccentedKey];
}

- (void)setUseAccentedVietnamese:(BOOL)useAccentedVietnamese {
    [self.defaults setBool:useAccentedVietnamese forKey:kVCAccentedKey];
    [self.defaults synchronize];
}

- (BOOL)includeCompanyInfo {
    return [self.defaults boolForKey:kVCCompanyKey];
}

- (void)setIncludeCompanyInfo:(BOOL)includeCompanyInfo {
    [self.defaults setBool:includeCompanyInfo forKey:kVCCompanyKey];
    [self.defaults synchronize];
}

- (BOOL)includeAvatarImages {
    return [self.defaults boolForKey:kVCAvatarKey];
}

- (void)setIncludeAvatarImages:(BOOL)includeAvatarImages {
    [self.defaults setBool:includeAvatarImages forKey:kVCAvatarKey];
    [self.defaults synchronize];
}

#pragma mark - Registry Persistence (Dual Backup: NSUserDefaults + Plist)

- (NSString *)backupRegistryFilePath {
    return ROOT_PATH_NS(@"/var/mobile/Library/Preferences/com.virtualcontacts.generator.registry.plist");
}

- (NSArray<NSString *> *)loadSavedIdentifiers {
    NSArray<NSString *> *ids = [self.defaults arrayForKey:kVCIdentifiersKey];
    if (ids.count > 0) {
        return ids;
    }
    NSDictionary *backup = [NSDictionary dictionaryWithContentsOfFile:[self backupRegistryFilePath]];
    NSArray<NSString *> *backupIds = backup[kVCIdentifiersKey];
    if (backupIds.count > 0) {
        [self.defaults setObject:backupIds forKey:kVCIdentifiersKey];
        [self.defaults synchronize];
        return backupIds;
    }
    return @[];
}

- (void)saveIdentifiers:(NSArray<NSString *> *)identifiers {
    NSArray<NSString *> *uniqueIds = [[NSOrderedSet orderedSetWithArray:identifiers] array];
    [self.defaults setObject:uniqueIds forKey:kVCIdentifiersKey];
    [self.defaults synchronize];

    NSDictionary *payload = @{
        kVCIdentifiersKey: uniqueIds,
        @"UpdatedAt": [NSDate date]
    };
    [payload writeToFile:[self backupRegistryFilePath] atomically:YES];
}

#pragma mark - Authorization & Container Inspection

- (CNAuthorizationStatus)currentAuthorizationStatus {
    return [CNContactStore authorizationStatusForEntityType:CNEntityTypeContacts];
}

- (void)requestContactsAccessWithCompletion:(void (^)(BOOL granted, NSError * _Nullable error))completion {
    CNAuthorizationStatus status = [self currentAuthorizationStatus];
    if (status == CNAuthorizationStatusAuthorized) {
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(YES, nil);
            });
        }
        return;
    }

    if (status == CNAuthorizationStatusDenied || status == CNAuthorizationStatusRestricted) {
        NSError *err = [NSError errorWithDomain:VCErrorDomain
                                           code:VCErrorCodePermissionDenied
                                       userInfo:@{NSLocalizedDescriptionKey: @"Quyền truy cập Danh bạ bị từ chối. Vui lòng bật quyền Danh bạ trong Cài đặt."}];
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO, err);
            });
        }
        return;
    }

    [self.contactStore requestAccessForEntityType:CNEntityTypeContacts completionHandler:^(BOOL granted, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (granted) {
                completion(YES, nil);
            } else {
                NSError *permErr = error ?: [NSError errorWithDomain:VCErrorDomain
                                                                code:VCErrorCodePermissionDenied
                                                            userInfo:@{NSLocalizedDescriptionKey: @"Không thể xin quyền truy cập Danh bạ từ hệ thống."}];
                completion(NO, permErr);
            }
        });
    }];
}

- (nullable CNContainer *)findLocalContainer {
    NSError *error = nil;
    NSArray<CNContainer *> *containers = [self.contactStore containersMatchingPredicate:nil error:&error];
    if (error || containers.count == 0) {
        return nil;
    }
    for (CNContainer *container in containers) {
        if (container.type == CNContainerTypeLocal) {
            return container;
        }
    }
    return nil;
}

- (BOOL)hasLocalContainerAvailable {
    return ([self findLocalContainer] != nil);
}

#pragma mark - Verification & Sync

- (BOOL)isVerifiedVirtualContact:(CNContact *)contact savedIdentifierSet:(NSSet<NSString *> *)savedSet {
    if (![savedSet containsObject:contact.identifier]) {
        return NO;
    }
    for (CNLabeledValue<NSString *> *emailVal in contact.emailAddresses) {
        NSString *email = emailVal.value.lowercaseString;
        if ([email hasSuffix:kVCTestEmailDomain] && [email containsString:@".vc"]) {
            return YES;
        }
    }
    for (CNLabeledValue<CNPhoneNumber *> *phoneVal in contact.phoneNumbers) {
        NSString *digits = phoneVal.value.stringValue;
        if ([digits containsString:@"24 0000"] || [digits containsString:@"240000"]) {
            return YES;
        }
    }
    return NO;
}

- (NSUInteger)syncAndCountExistingVirtualContacts {
    if ([self currentAuthorizationStatus] != CNAuthorizationStatusAuthorized) {
        return 0;
    }

    NSArray<NSString *> *savedIds = [self loadSavedIdentifiers];
    if (savedIds.count == 0) {
        return 0;
    }

    NSPredicate *predicate = [CNContact predicateForContactsWithIdentifiers:savedIds];
    NSArray<id<CNKeyDescriptor>> *keys = @[
        CNContactIdentifierKey,
        CNContactEmailAddressesKey,
        CNContactPhoneNumbersKey
    ];

    NSError *error = nil;
    NSArray<CNContact *> *matchedContacts = [self.contactStore unifiedContactsMatchingPredicate:predicate keysToFetch:keys error:&error];
    if (error) {
        NSLog(@"[VirtualContacts] Lỗi đồng bộ danh bạ: %@", error.localizedDescription);
        return savedIds.count;
    }

    NSSet<NSString *> *savedSet = [NSSet setWithArray:savedIds];
    NSMutableArray<NSString *> *stillExistingIds = [NSMutableArray array];
    for (CNContact *contact in matchedContacts) {
        if ([self isVerifiedVirtualContact:contact savedIdentifierSet:savedSet]) {
            [stillExistingIds addObject:contact.identifier];
        }
    }

    if (stillExistingIds.count != savedIds.count) {
        [self saveIdentifiers:stillExistingIds];
    }

    return stillExistingIds.count;
}

#pragma mark - Group Management

- (nullable CNGroup *)findOrCreateVirtualGroupInContainer:(NSString *)containerIdentifier {
    NSError *error = nil;
    NSPredicate *groupPredicate = [CNGroup predicateForGroupsInContainerWithIdentifier:containerIdentifier];
    NSArray<CNGroup *> *groups = [self.contactStore groupsMatchingPredicate:groupPredicate error:&error];
    if (!error) {
        for (CNGroup *group in groups) {
            if ([group.name isEqualToString:kVCGroupName]) {
                [self.defaults setObject:group.identifier forKey:kVCGroupIdentifierKey];
                [self.defaults synchronize];
                return group;
            }
        }
    }

    CNMutableGroup *newGroup = [[CNMutableGroup alloc] init];
    newGroup.name = kVCGroupName;
    CNSaveRequest *groupSave = [[CNSaveRequest alloc] init];
    [groupSave addGroup:newGroup toContainerWithIdentifier:containerIdentifier];

    NSError *createErr = nil;
    if ([self.contactStore executeSaveRequest:groupSave error:&createErr]) {
        [self.defaults setObject:newGroup.identifier forKey:kVCGroupIdentifierKey];
        [self.defaults synchronize];
        return [newGroup copy];
    }

    NSLog(@"[VirtualContacts] Container không hỗ trợ tạo Group riêng (bỏ qua): %@", createErr.localizedDescription);
    return nil;
}

- (void)removeEmptyVirtualGroupIfNeeded {
    NSString *groupId = [self.defaults stringForKey:kVCGroupIdentifierKey];
    if (groupId.length == 0) {
        return;
    }
    NSPredicate *pred = [CNGroup predicateForGroupsWithIdentifiers:@[groupId]];
    NSError *error = nil;
    NSArray<CNGroup *> *groups = [self.contactStore groupsMatchingPredicate:pred error:&error];
    if (error || groups.count == 0) {
        [self.defaults removeObjectForKey:kVCGroupIdentifierKey];
        return;
    }

    CNGroup *group = groups.firstObject;
    NSPredicate *membersPred = [CNContact predicateForContactsInGroupWithIdentifier:group.identifier];
    NSArray<CNContact *> *members = [self.contactStore unifiedContactsMatchingPredicate:membersPred
                                                                            keysToFetch:@[CNContactIdentifierKey]
                                                                                  error:nil];
    if (members.count == 0) {
        CNMutableGroup *mutableGroup = [group mutableCopy];
        CNSaveRequest *req = [[CNSaveRequest alloc] init];
        [req deleteGroup:mutableGroup];
        [self.contactStore executeSaveRequest:req error:nil];
        [self.defaults removeObjectForKey:kVCGroupIdentifierKey];
        [self.defaults synchronize];
    }
}

#pragma mark - Vietnamese Data & Avatar Generators

- (NSString *)stripVietnameseDiacritics:(NSString *)input {
    NSMutableString *mutable = [input mutableCopy];
    [mutable replaceOccurrencesOfString:@"Đ" withString:@"D" options:0 range:NSMakeRange(0, mutable.length)];
    [mutable replaceOccurrencesOfString:@"đ" withString:@"d" options:0 range:NSMakeRange(0, mutable.length)];
    CFStringTransform((__bridge CFMutableStringRef)mutable, NULL, kCFStringTransformStripCombiningMarks, NO);
    return [mutable copy];
}

- (NSData *)generateAvatarImageDataForInitials:(NSString *)initials colorIndex:(NSUInteger)index {
    NSArray<NSArray<UIColor *> *> *palettes = @[
        @[[UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0], [UIColor colorWithRed:0.08 green:0.40 blue:0.75 alpha:1.0]],
        @[[UIColor colorWithRed:0.18 green:0.75 blue:0.49 alpha:1.0], [UIColor colorWithRed:0.10 green:0.55 blue:0.35 alpha:1.0]],
        @[[UIColor colorWithRed:0.96 green:0.49 blue:0.19 alpha:1.0], [UIColor colorWithRed:0.85 green:0.32 blue:0.12 alpha:1.0]],
        @[[UIColor colorWithRed:0.56 green:0.35 blue:0.92 alpha:1.0], [UIColor colorWithRed:0.38 green:0.20 blue:0.72 alpha:1.0]],
        @[[UIColor colorWithRed:0.91 green:0.26 blue:0.45 alpha:1.0], [UIColor colorWithRed:0.72 green:0.14 blue:0.32 alpha:1.0]],
        @[[UIColor colorWithRed:0.00 green:0.70 blue:0.76 alpha:1.0], [UIColor colorWithRed:0.00 green:0.48 blue:0.55 alpha:1.0]]
    ];

    NSArray<UIColor *> *colors = palettes[index % palettes.count];
    CGSize size = CGSizeMake(200.0, 200.0);

    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.scale = 1.0;
    format.opaque = YES;

    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:size format:format];
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext * _Nonnull rendererContext) {
        CGContextRef ctx = rendererContext.CGContext;
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        NSArray *cgColors = @[(__bridge id)colors[0].CGColor, (__bridge id)colors[1].CGColor];
        CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)cgColors, NULL);

        CGContextDrawLinearGradient(ctx, gradient, CGPointZero, CGPointMake(size.width, size.height), 0);
        CGGradientRelease(gradient);
        CGColorSpaceRelease(colorSpace);

        NSDictionary *attrs = @{
            NSFontAttributeName: [UIFont systemFontOfSize:76.0 weight:UIFontWeightSemibold],
            NSForegroundColorAttributeName: [UIColor whiteColor]
        };
        CGSize textSize = [initials sizeWithAttributes:attrs];
        CGRect textRect = CGRectMake((size.width - textSize.width) / 2.0,
                                     (size.height - textSize.height) / 2.0,
                                     textSize.width,
                                     textSize.height);
        [initials drawInRect:textRect withAttributes:attrs];
    }];

    return UIImagePNGRepresentation(image);
}

- (NSArray<CNMutableContact *> *)buildVietnameseFakeContactsWithCount:(NSUInteger)count
                                                          includeNote:(BOOL)includeNote {
    NSArray<NSString *> *surnames = @[
        @"Nguyễn", @"Trần", @"Lê", @"Phạm", @"Hoàng", @"Huỳnh", @"Phan", @"Vũ",
        @"Võ", @"Đặng", @"Bùi", @"Đỗ", @"Hồ", @"Ngô", @"Dương", @"Lý"
    ];

    NSArray<NSArray<NSString *> *> *givenNamePairs = @[
        @[@"Quốc", @"Bảo"], @[@"Hoàng", @"Nam"], @[@"Gia", @"Huy"], @[@"Thanh", @"Tùng"],
        @[@"Đức", @"Anh"], @[@"Tuấn", @"Kiệt"], @[@"Hải", @"Đăng"], @[@"Quang", @"Vinh"],
        @[@"Bảo", @"Long"], @[@"Minh", @"Quân"], @[@"Trọng", @"Nghĩa"], @[@"Công", @"Minh"],
        @[@"Đình", @"Phong"], @[@"Văn", @"Hùng"], @[@"Nhật", @"Minh"],
        @[@"Minh", @"Anh"], @[@"Ngọc", @"Hà"], @[@"Thảo", @"Vy"], @[@"Khánh", @"Linh"],
        @[@"Phương", @"Anh"], @[@"Bảo", @"Ngọc"], @[@"Thu", @"Hà"], @[@"Thanh", @"Trúc"],
        @[@"Quỳnh", @"Như"], @[@"Lan", @"Anh"], @[@"Mai", @"Phương"], @[@"Tú", @"Anh"],
        @[@"Diệu", @"Linh"], @[@"Ánh", @"Tuyết"], @[@"Hoàng", @"Yến"]
    ];

    NSArray<NSString *> *companies = @[
        @"Công ty Công nghệ Sao Việt (Demo)",
        @"Tập đoàn Giải pháp Số Đại Nam (Test)",
        @"VNCloud Software Labs",
        @"Saigon Digital Systems",
        @"Hanoi Tech Innovation JSC",
        @"Mekong Data Analytics Co., Ltd"
    ];

    NSArray<NSString *> *jobTitles = @[
        @"Kỹ sư Phần mềm", @"Chuyên viên Kiểm thử QA", @"Quản lý Sản phẩm",
        @"Kiến trúc sư Hệ thống", @"Chuyên viên Phân tích Dữ liệu", @"Thiết kế UI/UX"
    ];

    NSMutableArray<CNMutableContact *> *result = [NSMutableArray arrayWithCapacity:count];
    NSMutableSet<NSString *> *usedFullNames = [NSMutableSet setWithCapacity:count];

    BOOL accented = self.useAccentedVietnamese;
    BOOL withCompany = self.includeCompanyInfo;
    BOOL withAvatar = self.includeAvatarImages;

    NSUInteger seedOffset = arc4random_uniform(100);

    for (NSUInteger i = 0; i < count; i++) {
        NSString *familyName = nil;
        NSString *middleName = nil;
        NSString *givenName = nil;
        NSString *fullNameKey = nil;

        NSUInteger attempt = 0;
        do {
            NSUInteger sIdx = (i * 7 + seedOffset + attempt) % surnames.count;
            NSUInteger gIdx = (i * 13 + seedOffset + attempt / surnames.count) % givenNamePairs.count;
            familyName = surnames[sIdx];
            middleName = givenNamePairs[gIdx][0];
            givenName = givenNamePairs[gIdx][1];
            fullNameKey = [NSString stringWithFormat:@"%@ %@ %@", familyName, middleName, givenName];
            attempt++;
        } while ([usedFullNames containsObject:fullNameKey] && attempt < 500);

        [usedFullNames addObject:fullNameKey];

        NSString *displayFamily = accented ? familyName : [self stripVietnameseDiacritics:familyName];
        NSString *displayMiddle = accented ? middleName : [self stripVietnameseDiacritics:middleName];
        NSString *displayGiven = accented ? givenName : [self stripVietnameseDiacritics:givenName];

        CNMutableContact *contact = [[CNMutableContact alloc] init];
        contact.familyName = displayFamily;
        contact.middleName = displayMiddle;
        contact.givenName = displayGiven;

        NSString *phoneStr = [NSString stringWithFormat:@"+84 24 0000 %04lu", (unsigned long)(i + 1)];
        CNPhoneNumber *phone = [CNPhoneNumber phoneNumberWithStringValue:phoneStr];
        contact.phoneNumbers = @[
            [CNLabeledValue labeledValueWithLabel:CNLabelPhoneNumberMobile value:phone]
        ];

        NSString *cleanFamily = [self stripVietnameseDiacritics:familyName].lowercaseString;
        NSString *cleanMiddle = [self stripVietnameseDiacritics:middleName].lowercaseString;
        NSString *cleanGiven = [self stripVietnameseDiacritics:givenName].lowercaseString;
        NSString *emailStr = [NSString stringWithFormat:@"%@.%@.%@.vc%03lu@%@",
                              cleanFamily, cleanMiddle, cleanGiven, (unsigned long)(i + 1), kVCTestEmailDomain];
        contact.emailAddresses = @[
            [CNLabeledValue labeledValueWithLabel:CNLabelWork value:emailStr]
        ];

        if (withCompany) {
            contact.organizationName = companies[i % companies.count];
            contact.jobTitle = jobTitles[i % jobTitles.count];
        }

        if (withAvatar) {
            NSString *firstChar = displayFamily.length > 0 ? [displayFamily substringToIndex:1] : @"V";
            NSString *lastChar = displayGiven.length > 0 ? [displayGiven substringToIndex:1] : @"C";
            NSString *initials = [[NSString stringWithFormat:@"%@%@", firstChar, lastChar] uppercaseString];
            contact.imageData = [self generateAvatarImageDataForInitials:initials colorIndex:i];
        }

        if (includeNote) {
            NSString *uuidTag = [[NSUUID UUID] UUIDString];
            contact.note = [NSString stringWithFormat:@"[VC-ID:%@] Danh bạ ảo phục vụ kiểm thử (Virtual Contacts)", uuidTag];
        }

        [result addObject:contact];
    }

    return [result copy];
}

#pragma mark - Generate 100 Contacts

- (void)generateVirtualContactsWithCount:(NSUInteger)count
                      allowCloudFallback:(BOOL)allowCloudFallback
                                progress:(void (^ _Nullable)(NSUInteger current, NSUInteger total))progressHandler
                              completion:(void (^)(NSUInteger createdCount, BOOL usedLocalContainer, NSError * _Nullable error))completion {
    if (self.isBusy) {
        NSError *busyErr = [NSError errorWithDomain:VCErrorDomain
                                               code:VCErrorCodeBusy
                                           userInfo:@{NSLocalizedDescriptionKey: @"Hệ thống đang xử lý tác vụ khác. Vui lòng đợi hoàn tất."}];
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(0, NO, busyErr);
            });
        }
        return;
    }

    self.isBusy = YES;

    [self requestContactsAccessWithCompletion:^(BOOL granted, NSError * _Nullable permError) {
        if (!granted) {
            self.isBusy = NO;
            if (completion) {
                completion(0, NO, permError);
            }
            return;
        }

        dispatch_async(self.workerQueue, ^{
            NSUInteger existingCount = [self syncAndCountExistingVirtualContacts];
            if (existingCount >= count) {
                self.isBusy = NO;
                NSString *msg = [NSString stringWithFormat:@"Đã tồn tại %lu danh bạ ảo. Vui lòng xóa danh bạ ảo cũ trước khi tạo lại.", (unsigned long)existingCount];
                NSError *dupErr = [NSError errorWithDomain:VCErrorDomain
                                                      code:VCErrorCodeAlreadyExists
                                                  userInfo:@{NSLocalizedDescriptionKey: msg}];
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (completion) completion(0, NO, dupErr);
                });
                return;
            }

            NSUInteger remainingToCreate = count - existingCount;
            CNContainer *localContainer = [self findLocalContainer];
            BOOL usingLocal = (localContainer != nil);
            NSString *targetContainerId = usingLocal ? localContainer.identifier : [self.contactStore defaultContainerIdentifier];

            if (!usingLocal && !allowCloudFallback) {
                self.isBusy = NO;
                NSError *cloudErr = [NSError errorWithDomain:VCErrorDomain
                                                        code:VCErrorCodeNoLocalContainer
                                                    userInfo:@{NSLocalizedDescriptionKey: @"iCloud Contacts đang bật nên iOS ẩn bộ nhớ danh bạ cục bộ. Bạn có muốn tiếp tục tạo vào nhóm riêng 'Virtual Contacts' trên tài khoản mặc định không?"}];
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (completion) completion(0, NO, cloudErr);
                });
                return;
            }

            if (targetContainerId.length == 0) {
                self.isBusy = NO;
                NSError *noContainerErr = [NSError errorWithDomain:VCErrorDomain
                                                              code:VCErrorCodeSaveFailed
                                                          userInfo:@{NSLocalizedDescriptionKey: @"Không tìm thấy nguồn lưu trữ danh bạ hợp lệ trên thiết bị."}];
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (completion) completion(0, NO, noContainerErr);
                });
                return;
            }

            CNGroup *virtualGroup = [self findOrCreateVirtualGroupInContainer:targetContainerId];
            NSArray<CNMutableContact *> *contactsToSave = [self buildVietnameseFakeContactsWithCount:remainingToCreate includeNote:YES];

            NSMutableArray<NSString *> *allSavedIds = [[self loadSavedIdentifiers] mutableCopy];
            NSUInteger batchSize = 25;
            NSUInteger totalCreated = 0;
            NSError *lastSaveError = nil;
            BOOL noteEntitled = YES;

            for (NSUInteger start = 0; start < contactsToSave.count; start += batchSize) {
                NSUInteger len = MIN(batchSize, contactsToSave.count - start);
                NSArray<CNMutableContact *> *chunk = [contactsToSave subarrayWithRange:NSMakeRange(start, len)];

                CNSaveRequest *saveRequest = [[CNSaveRequest alloc] init];
                for (CNMutableContact *c in chunk) {
                    if (!noteEntitled) {
                        c.note = @"";
                    }
                    [saveRequest addContact:c toContainerWithIdentifier:targetContainerId];
                    if (virtualGroup != nil) {
                        [saveRequest addMember:c toGroup:virtualGroup];
                    }
                }

                NSError *batchError = nil;
                BOOL success = [self.contactStore executeSaveRequest:saveRequest error:&batchError];

                if (!success && batchError.code == 102 && noteEntitled) {
                    noteEntitled = NO;
                    CNSaveRequest *retryRequest = [[CNSaveRequest alloc] init];
                    for (CNMutableContact *c in chunk) {
                        c.note = @"";
                        [retryRequest addContact:c toContainerWithIdentifier:targetContainerId];
                        if (virtualGroup != nil) {
                            [retryRequest addMember:c toGroup:virtualGroup];
                        }
                    }
                    batchError = nil;
                    success = [self.contactStore executeSaveRequest:retryRequest error:&batchError];
                }

                if (!success) {
                    lastSaveError = batchError;
                    NSLog(@"[VirtualContacts] Lỗi lưu batch tại vị trí %lu: %@", (unsigned long)start, batchError);
                    break;
                }

                for (CNMutableContact *c in chunk) {
                    if (c.identifier.length > 0) {
                        [allSavedIds addObject:c.identifier];
                    }
                }
                [self saveIdentifiers:allSavedIds];
                totalCreated += chunk.count;

                NSUInteger currentProgress = totalCreated;
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (progressHandler) {
                        progressHandler(currentProgress, remainingToCreate);
                    }
                });
            }

            self.isBusy = NO;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (completion) {
                    completion(totalCreated, usingLocal, lastSaveError);
                }
            });
        });
    }];
}

#pragma mark - Delete Virtual Contacts Safely

- (void)deleteAllVirtualContactsWithProgress:(void (^ _Nullable)(NSUInteger current, NSUInteger total))progressHandler
                                  completion:(void (^)(NSUInteger deletedCount, NSError * _Nullable error))completion {
    if (self.isBusy) {
        NSError *busyErr = [NSError errorWithDomain:VCErrorDomain
                                               code:VCErrorCodeBusy
                                           userInfo:@{NSLocalizedDescriptionKey: @"Hệ thống đang xử lý tác vụ khác. Vui lòng đợi."}];
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(0, busyErr);
            });
        }
        return;
    }

    self.isBusy = YES;

    [self requestContactsAccessWithCompletion:^(BOOL granted, NSError * _Nullable permError) {
        if (!granted) {
            self.isBusy = NO;
            if (completion) {
                completion(0, permError);
            }
            return;
        }

        dispatch_async(self.workerQueue, ^{
            NSArray<NSString *> *savedIds = [self loadSavedIdentifiers];
            if (savedIds.count == 0) {
                [self removeEmptyVirtualGroupIfNeeded];
                self.isBusy = NO;
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (completion) completion(0, nil);
                });
                return;
            }

            NSPredicate *predicate = [CNContact predicateForContactsWithIdentifiers:savedIds];
            NSArray<id<CNKeyDescriptor>> *keys = @[
                CNContactIdentifierKey,
                CNContactEmailAddressesKey,
                CNContactPhoneNumbersKey
            ];

            NSError *fetchErr = nil;
            NSArray<CNContact *> *fetched = [self.contactStore unifiedContactsMatchingPredicate:predicate keysToFetch:keys error:&fetchErr];
            if (fetchErr) {
                self.isBusy = NO;
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (completion) completion(0, fetchErr);
                });
                return;
            }

            NSSet<NSString *> *savedSet = [NSSet setWithArray:savedIds];
            NSMutableArray<CNContact *> *verifiedToDelete = [NSMutableArray array];
            for (CNContact *c in fetched) {
                if ([self isVerifiedVirtualContact:c savedIdentifierSet:savedSet]) {
                    [verifiedToDelete addObject:c];
                }
            }

            if (verifiedToDelete.count == 0) {
                [self saveIdentifiers:@[]];
                [self removeEmptyVirtualGroupIfNeeded];
                self.isBusy = NO;
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (completion) completion(0, nil);
                });
                return;
            }

            NSMutableSet<NSString *> *remainingIdSet = [NSMutableSet setWithArray:savedIds];
            NSUInteger totalToDelete = verifiedToDelete.count;
            NSUInteger batchSize = 25;
            NSUInteger deletedTotal = 0;
            NSError *deleteError = nil;

            for (NSUInteger start = 0; start < totalToDelete; start += batchSize) {
                NSUInteger len = MIN(batchSize, totalToDelete - start);
                NSArray<CNContact *> *chunk = [verifiedToDelete subarrayWithRange:NSMakeRange(start, len)];

                CNSaveRequest *deleteRequest = [[CNSaveRequest alloc] init];
                for (CNContact *c in chunk) {
                    CNMutableContact *mutableContact = [c mutableCopy];
                    [deleteRequest deleteContact:mutableContact];
                }

                NSError *batchErr = nil;
                if (![self.contactStore executeSaveRequest:deleteRequest error:&batchErr]) {
                    deleteError = batchErr;
                    NSLog(@"[VirtualContacts] Lỗi xóa batch danh bạ ảo: %@", batchErr);
                    break;
                }

                for (CNContact *c in chunk) {
                    [remainingIdSet removeObject:c.identifier];
                }
                [self saveIdentifiers:[remainingIdSet allObjects]];
                deletedTotal += chunk.count;

                NSUInteger currentProg = deletedTotal;
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (progressHandler) {
                        progressHandler(currentProg, totalToDelete);
                    }
                });
            }

            if (remainingIdSet.count == 0) {
                [self removeEmptyVirtualGroupIfNeeded];
            }

            self.isBusy = NO;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (completion) {
                    completion(deletedTotal, deleteError);
                }
            });
        });
    }];
}

@end
