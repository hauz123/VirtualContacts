#import <Foundation/Foundation.h>
#import <Contacts/Contacts.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, VCErrorCode) {
    VCErrorCodeBusy = 1001,
    VCErrorCodePermissionDenied = 1002,
    VCErrorCodeAlreadyExists = 1003,
    VCErrorCodeNoLocalContainer = 1004,
    VCErrorCodeSaveFailed = 1005,
    VCErrorCodeDeleteFailed = 1006
};

extern NSString * const VCErrorDomain;

@interface VirtualContactsManager : NSObject

@property (nonatomic, assign, readonly) BOOL isBusy;
@property (nonatomic, assign) BOOL useAccentedVietnamese;
@property (nonatomic, assign) BOOL includeCompanyInfo;
@property (nonatomic, assign) BOOL includeAvatarImages;
@property (nonatomic, assign) NSUInteger targetContactCount;

+ (instancetype)sharedManager;

- (CNAuthorizationStatus)currentAuthorizationStatus;
- (void)requestContactsAccessWithCompletion:(void (^)(BOOL granted, NSError * _Nullable error))completion;

/// Đồng bộ hóa và trả về số lượng danh bạ ảo thực sự đang tồn tại trong hệ thống
- (NSUInteger)syncAndCountExistingVirtualContacts;

/// Kiểm tra thiết bị có hỗ trợ Container cục bộ (không đồng bộ iCloud) hay không
- (BOOL)hasLocalContainerAvailable;

/// Tạo danh bạ ảo với tiến trình theo thời gian thực
- (void)generateVirtualContactsWithCount:(NSUInteger)count
                      allowCloudFallback:(BOOL)allowCloudFallback
                                progress:(void (^ _Nullable)(NSUInteger current, NSUInteger total))progressHandler
                              completion:(void (^)(NSUInteger createdCount, BOOL usedLocalContainer, NSError * _Nullable error))completion;

/// Xóa toàn bộ danh bạ ảo do tweak tạo (tuyệt đối không chạm vào danh bạ thật)
- (void)deleteAllVirtualContactsWithProgress:(void (^ _Nullable)(NSUInteger current, NSUInteger total))progressHandler
                                  completion:(void (^)(NSUInteger deletedCount, NSError * _Nullable error))completion;

@end

NS_ASSUME_NONNULL_END
