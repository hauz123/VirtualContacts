#!/usr/bin/env bash
set -e

if [ -z "$THEOS" ]; then
    if [ -d "/var/jb/theos" ]; then
        export THEOS="/var/jb/theos"
    elif [ -d "$HOME/theos" ]; then
        export THEOS="$HOME/theos"
    elif [ -d "/opt/theos" ]; then
        export THEOS="/opt/theos"
    else
        echo "Lỗi: Không tìm thấy biến môi trường THEOS. Hãy cài Theos hoặc export THEOS=/duong/dan/theos"
        exit 1
    fi
fi

echo "==> Đang build Virtual Contacts (Rootless ARM64)..."
make clean
make package FINALPACKAGE=1
echo "==> Hoàn tất! File .deb nằm tại thư mục packages/:"
ls -lh packages/*.deb
