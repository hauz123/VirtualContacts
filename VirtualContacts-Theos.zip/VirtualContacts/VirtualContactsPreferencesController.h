#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, PSCellType) {
    PSGroupCell = 0,
    PSLinkCell = 1,
    PSLinkListCell = 2,
    PSListItemCell = 3,
    PSTitleValueCell = 4,
    PSSliderCell = 5,
    PSSwitchCell = 6,
    PSStaticTextCell = 7,
    PSEditTextCell = 8,
    PSSegmentCell = 9,
    PSGiantIconCell = 10,
    PSGiantCell = 11,
    PSSecureEditTextCell = 12,
    PSButtonCell = 13,
    PSEditTextViewCell = 14,
};

@interface PSSpecifier : NSObject
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *identifier;
+ (instancetype)preferenceSpecifierNamed:(nullable NSString *)title
                                  target:(nullable id)target
                                     set:(nullable SEL)set
                                     get:(nullable SEL)get
                                  detail:(nullable Class)detail
                                    cell:(PSCellType)cell
                                    edit:(nullable Class)edit;
+ (instancetype)groupSpecifierWithName:(nullable NSString *)name;
- (void)setProperty:(id)property forKey:(NSString *)key;
- (nullable id)propertyForKey:(NSString *)key;
- (void)setButtonAction:(SEL)buttonAction;
@end

@interface PSViewController : UIViewController
@end

@interface PSListController : PSViewController {
    NSArray *_specifiers;
}
- (NSArray *)specifiers;
- (void)reloadSpecifiers;
- (UITableView *)table;
@end

@interface VirtualContactsPreferencesController : PSListController
@end

NS_ASSUME_NONNULL_END
